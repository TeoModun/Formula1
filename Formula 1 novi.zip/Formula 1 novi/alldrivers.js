$(document).ready(function() {
    $.getJSON("http://ergast.com/api/f1/drivers?=123.json", function(data) { 
      console.log(data);
    });
});
