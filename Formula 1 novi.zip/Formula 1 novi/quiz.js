$(document).ready(function(){
    $("#draggable1").draggable();
    $("#droppable1").droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "#prvi" )
            .html( "Correct!" );
      }
    });
    $("#draggable2").draggable();
    $("#droppable2").droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          .find( "#drugi" )
            .html( "Correct!" );
      }
    });
})