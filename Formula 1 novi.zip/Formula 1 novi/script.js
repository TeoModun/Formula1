
$(document).ready(function(){
$(".theme-switch-container").on("change",".theme-slider",function() { 
    $("body").toggleClass("dark");
    $(".content").toggleClass("dark");
    $(".content-right").toggleClass("dark");
    $(".content-video").toggleClass("dark");
    $(".content-interviews").toggleClass("dark");
  });
  $(".theme-switch-container").on("change",".theme-slider",function() { 
    $(".panel").toggleClass("dark");
  });
  $( ".button2" ).click(function() {
    $( ".p-interview2" ).toggle( "fast");
  });
  $( ".button3" ).click(function() {
    $( ".p-interview3" ).toggle( "fast");
  });
  $( ".button1" ).click(function() {
    $( ".p-interview1" ).toggle("fast");
  });
  var acc = document.getElementsByClassName("accordion");
  var i;
  for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var panel = this.nextElementSibling;
      if (panel.style.display === "block") {
        panel.style.display = "none";
      } else {
        panel.style.display = "block";
      }
    });
  }
});