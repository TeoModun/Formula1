
$(document).ready(function(){
    $( ".timeline" ).slider();
});